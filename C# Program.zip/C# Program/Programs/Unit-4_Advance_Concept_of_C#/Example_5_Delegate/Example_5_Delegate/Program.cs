﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_5_Delegate
{
    //A delegate is an object which refers to a method or you can say it 
    //is a reference type variable that can hold a reference to the methods.
    class Program
    {
        class calculator
        {
            public delegate void action(int a, int b);//delegate declaration
            public void sum(int a, int b)
            {
                int c = a + b;
                Console.WriteLine("Sum=" + c);
            }
            public void sub(int a, int b)
            {
                int c = a - b;
                Console.Write("sub=" + c);
            }
            static void Main(string[] args)
            {
                calculator c = new calculator();
                action op1 = new action(c.sum);
                action op2 = new action(c.sub);
                op1(10, 20);
                op2(50, 10);
                Console.ReadLine();
            }
        }
    }
}




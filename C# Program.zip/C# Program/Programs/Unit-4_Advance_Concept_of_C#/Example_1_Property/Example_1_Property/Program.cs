﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_1_Property
{
    class employee
    {
        private string name;
        public string emp
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            employee e1 = new employee();
            e1.emp = "RKU";
            Console.WriteLine("Name=" + e1.emp);
            Console.ReadLine();
        }
    }
}

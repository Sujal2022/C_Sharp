﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_16_Exception_Handling
{
    class Program
    {
        static void Main(string[] args)
        {
            //code without try-catch
           // int a = 10;
           // int b = 0;
           // int x = a / b;
           Console.WriteLine("Rest of the code");
            // with try-catch
            try
            {
                int a = 10;
                int b = 0;
                int x = a / b;
            }
            catch (Exception e) 
            { 
                Console.WriteLine(e); 
            }
            Console.WriteLine("Rest of the code");
            Console.ReadLine();
        }
    }
}

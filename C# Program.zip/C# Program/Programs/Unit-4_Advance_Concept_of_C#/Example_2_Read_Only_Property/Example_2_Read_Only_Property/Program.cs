﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_2_Read_Only_Property
{
    public class emp
    {
        private static int abc=0;
        public emp()
        {
            abc++;
        }
        public static int Counter
        {
            get
            {
                return abc;
            }
        }
    }  
    class Program
    {
        static void Main(string[] args)
        {
            emp e1 = new emp();
            emp e2 = new emp();
            emp e3 = new emp();
            //e1.Counter = 10;//Compile Time Error: Can't set value  
            Console.WriteLine("No. of Employees: " + emp.Counter);  
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_7_Event
{
    class Program
    {
     public class mytest
    {
        public event EventHandler MyEvent
        {
            add
            {
                Console.WriteLine("add operation");
            }
            remove
            {
                Console.WriteLine("remove operation");
            }
    }
}
    public class Test
    {
        public void TestEvent()
        {
            mytest m = new mytest();
            m.MyEvent += testevent;
            m.MyEvent -= testevent;
        }
        public void testevent(object sender, EventArgs e)
       {
       }
}
        static void Main(string[] args)
        {
            Test t = new Test();
            t.TestEvent();
            Console.ReadLine();
        }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_3_Static_Property
{
    public class emp
    {
        public static int number = 0;
        public emp()
        {
            number++;
        }
        public static int count
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("object = " + emp.count);

            emp obj1 = new emp();
            Console.WriteLine("object = " + emp.count);

            emp obj2 = new emp();
            Console.WriteLine("object = " + emp.count);

            emp obj3 = new emp();
            Console.WriteLine("object = " + emp.count);
            Console.ReadLine();
        }
    }
}

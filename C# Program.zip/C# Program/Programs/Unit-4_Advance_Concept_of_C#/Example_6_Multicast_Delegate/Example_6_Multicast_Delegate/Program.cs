﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_6_Multicast_Delegate
{
    class Program
    {
     delegate void emp(string s);//multicast delegate
        class test
        {
            public static void hello(string s)
            {
                Console.WriteLine("Hello "+s);
            }
            public static void goodbye(string s)
            {
                Console.WriteLine("goodbye "+s);
            }
          static void Main(string[] args)
            {
                emp a,b,c,d;
                a = hello;
                b = goodbye;
                c = a + b;
                d = b - a;
                Console.WriteLine("Call object a");
                a("A");
                Console.WriteLine("Call object b");
                b("B");
                Console.WriteLine("Call object c");
                c("C");
                Console.WriteLine("Call object d");
                d("D");
                Console.ReadLine();
            }
        }
    }
}


    

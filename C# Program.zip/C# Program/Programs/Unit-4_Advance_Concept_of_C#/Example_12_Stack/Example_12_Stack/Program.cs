﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_12_Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<string> names = new Stack<string>();
            names.Push("Car");
            names.Push("Bike");
            names.Push("Auto");
            names.Push("Cycle");
            names.Push("Bus");

            foreach (string name in names)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("Peek element: " + names.Peek());//Display first element
            Console.WriteLine("Pop: " + names.Pop());//remove first element
            Console.WriteLine("After Pop, Peek element: " + names.Peek());//after removing ifrst element 2nd element displays as first element
            Console.ReadLine();
  
        }
    }
}

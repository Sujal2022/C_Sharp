﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_10_HasSet
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a set of strings  that adds unique value
            var names = new HashSet<string>();
            names.Add("Hi");
            names.Add("Hello");
            names.Add("Good");
            names.Add("Bye");
            names.Add("Hi");//will not be added  
            names.Add("haha");

            // Iterate HashSet elements using foreach loop  
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
            Console.ReadLine();
        }
    }
}

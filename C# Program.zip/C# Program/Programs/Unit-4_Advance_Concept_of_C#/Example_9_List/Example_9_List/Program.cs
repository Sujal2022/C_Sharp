﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_9_List
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a list of strings  
            var names = new List<string>();
            names.Add("Hello");
            names.Add("Hi");
            names.Add("Good");
            names.Add("Bye");
            foreach (var n in names)
            {
                Console.WriteLine(n);
            }
            Console.ReadLine();
        }
    }
}

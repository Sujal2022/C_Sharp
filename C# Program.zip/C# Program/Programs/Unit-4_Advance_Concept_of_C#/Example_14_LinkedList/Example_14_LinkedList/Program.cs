﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_14_LinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a list of strings  
            var names = new LinkedList<string>();
            names.AddLast("A");
            names.AddLast("B");
            names.AddLast("C");
            names.AddLast("D");
           
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("Insert new Element Before B");
           
            LinkedListNode<String> node = names.Find("B");
            names.AddBefore(node, "E");
            names.AddAfter(node, "F");

            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
            Console.ReadLine();
        }
    }
}

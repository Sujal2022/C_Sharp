﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_11_SortedSet
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a set of strings, will display in ascending order 
            var names = new SortedSet<string>() { "Bike", "Cycle", "Auto", "Bus" };

            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
            Console.ReadLine();
        }
    }
}

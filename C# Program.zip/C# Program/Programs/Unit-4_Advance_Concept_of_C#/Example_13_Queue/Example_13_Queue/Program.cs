﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_13_Queue
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<string> names = new Queue<string>();
            names.Enqueue("car");
            names.Enqueue("auto");
            names.Enqueue("bike");
            names.Enqueue("bus");
            names.Enqueue("cycle");

            foreach (string name in names)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("Peek element: " + names.Peek  ());//display first element
            Console.WriteLine("Dequeue: " + names.Dequeue());//remove first element
            Console.WriteLine("After Dequeue, Peek element: " + names.Peek());//after removing 2nd element is first
            Console.ReadLine();
        }
    }
}

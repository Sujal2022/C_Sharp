﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_8_Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a list of strings using collection initializer  
            var names = new List<string>() { "Hi", "Hello", "Good", "Bye" };

            foreach (var vr in names)
            {
                Console.WriteLine(vr);
            }
            Console.ReadLine();
        }
    }
}

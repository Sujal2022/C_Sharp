﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_4_Indexer_Property
{
    class Indx
    {
        private string[] val = new string[3];
        public string this[int index]
        {
            get
            {
                return val[index];
            }
            set
            {
               val[index] = value;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Indx i = new Indx();
            
            i[0] = "apple";
            i[1] = "mango";
            i[2] = "grapes";

            Console.Write("values stored in objects used as arrays\n");
            Console.WriteLine("First value ="+i[0]);
            Console.WriteLine("Second value ="+i[1]);
            Console.WriteLine("Third value ="+ i[2]);
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Exercises_7_Filter_data
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\LENOVO\Documents\emp.mdf;Integrated Security=True;Connect Timeout=30");
        private void btnFilter_Click(object sender, EventArgs e)
        {
            int price = Convert.ToInt32(txtPrice.Text);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from product where price < "+price+"", con);
            DataSet ds = new DataSet();
            da.Fill(ds,"product");
            dataGridView1.DataSource = ds.Tables["product"].DefaultView;

            con.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Exercises_8_Sorting
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\LENOVO\Documents\emp.mdf;Integrated Security=True;Connect Timeout=30");
        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();
            string str = "SELECT column_name FROM information_schema.columns WHERE table_name = 'product'";
            SqlCommand command = new SqlCommand(str, con);
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    string columnName = reader["COLUMN_NAME"].ToString();
                    cmbColumn.Items.Add(columnName);
                }
                con.Close();

            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from product", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "product");
            dataGridView1.DataSource = ds.Tables["product"].DefaultView;
            DataView dv1 = new DataView(ds.Tables[0]);
            dv1.Sort = cmbColumn.Text;
            dataGridView1.DataSource = dv1;
            con.Close();
        }
        public void displaydata()
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from product", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "product");
            dataGridView1.DataSource = ds.Tables["product"].DefaultView;
            con.Close();
        }
    }
}

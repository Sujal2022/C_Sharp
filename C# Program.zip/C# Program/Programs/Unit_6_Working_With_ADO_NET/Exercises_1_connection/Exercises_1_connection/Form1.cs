﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Exercises_1_connection
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string con = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\LENOVO\Documents\emp.mdf;Integrated Security=True;Connect Timeout=30";
            try
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    MessageBox.Show("Connection done");
                }
            }
            catch (Exception er)
            {
                MessageBox.Show("Connection fail");
            }
            
           
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Program_2_Insert_Update_delete
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        string con = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\LENOVO\Documents\emp.mdf;Integrated Security=True;Connect Timeout=30";
        
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            string name = txtName.Text;
            string city = txtCity.Text;
            SqlConnection cn = new SqlConnection(con);
            cn.Open();
            SqlCommand cmd = new SqlCommand("insert into employee values("+id+",'"+name+"','"+city+"')", cn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Inserted Successfully");
            cn.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            SqlConnection cn = new SqlConnection(con);
            cn.Open();
            SqlCommand cmd = new SqlCommand("delete from employee where sid="+id+"", cn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted Successfully");
            cn.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            string name = txtName.Text;
            string city = txtCity.Text;
            SqlConnection cn = new SqlConnection(con);
            cn.Open();
            SqlCommand cmd = new SqlCommand("update employee set sname='"+name+"',scity='"+city+"' where sid="+id+"", cn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Successfully");
            cn.Close();
        }
    }
}

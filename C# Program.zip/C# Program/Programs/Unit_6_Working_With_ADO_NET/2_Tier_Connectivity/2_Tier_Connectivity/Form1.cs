﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _2_Tier_Connectivity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string s = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Aysha\source\repos\2_Tier_Connectivity\2_Tier_Connectivity\employee.mdf;Integrated Security=True";
        
        SqlConnection con;//connection
        SqlCommand cmd;//insert, update, delete
        SqlDataAdapter da;//select
        DataSet ds;//select
        string g;


        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }
        void gender()
        {
            if (rdbml.Checked == true)
            {
                g = "Male";
            }
            else
            {
                g = "Female";
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            getcon();
            fillgrid();
            col();
        }


        void col()
        {
            dataGridView1.AutoGenerateColumns = false;


            DataGridViewButtonColumn edit = new DataGridViewButtonColumn();

            edit.FlatStyle = FlatStyle.Popup;
            edit.HeaderText = "Edit";
            edit.Name = "Edit";

            edit.UseColumnTextForButtonValue = true;

            edit.Text = "Edit";
            edit.Width = 60;
            dataGridView1.Columns.Add(edit);

            //delete

            DataGridViewButtonColumn delete = new DataGridViewButtonColumn();

            delete.FlatStyle = FlatStyle.Popup;
            delete.HeaderText = "delete";
            delete.Name = "delete";

            delete.UseColumnTextForButtonValue = true;

            delete.Text = "delete";
            delete.Width = 60;

            dataGridView1.Columns.Add(delete);

        }
        private void rdbfml_CheckedChanged(object sender, EventArgs e)
        {
            gender();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "Submit")
            {
                getcon();
                cmd = new SqlCommand("insert into emp_tbl (Name,Gender,Email,City,Address,Mobile)" +
                    "values('"+txtnm.Text+"','" + g + "','" + txteml.Text + "','" + cmbct.SelectedItem + "','" + txtadd.Text + "','" + txtmbl.Text + "')", con);
                cmd.ExecuteNonQuery();
                fillgrid();
            }
        }

        void fillgrid()
        {
            getcon();
            da = new SqlDataAdapter("select * from emp_tbl", con);
            ds = new DataSet();
            da.Fill(ds);

            dataGridView1.DataSource = ds.Tables[0];
        }
        void filldata()
        {
            getcon();
            da = new SqlDataAdapter("select * from emp_tbl" +
                " where Id='" + Program.id + "'", con);
            ds = new DataSet();
            da.Fill(ds);


            txtnm.Text = ds.Tables[0].Rows[0][1].ToString();
            if (rdbml.Text == ds.Tables[0].Rows[0][2].ToString())

            {
                rdbml.Checked = true;

            }
            else
            {
                rdbfml.Checked = true;
            }
            txteml.Text = ds.Tables[0].Rows[0][3].ToString();
            cmbct.SelectedItem = ds.Tables[0].Rows[0][4].ToString();
            txtadd.Text = ds.Tables[0].Rows[0][5].ToString();
            txtmbl.Text = ds.Tables[0].Rows[0][6].ToString();
        }
        private void rdbml_CheckedChanged(object sender, EventArgs e)
        {
            gender();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 7)
            {
                button1.Text = "Update";
                Program.id = Convert.ToInt16(dataGridView1.Rows
                    [e.RowIndex].Cells["Id"].FormattedValue);
                filldata();
            }
            else if (e.ColumnIndex == 8)
            {
                getcon();
                Program.id = Convert.ToInt16(dataGridView1.Rows
                    [e.RowIndex].Cells["Id"].FormattedValue);
                
                SqlCommand cmd = new SqlCommand("delete from emp_tbl where Id='" + Program.id + "'", con);
                cmd.ExecuteNonQuery();
                
                fillgrid();
            }

        }
    }
}

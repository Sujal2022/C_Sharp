﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Exercises_4_Insert_Display
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string con = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\LENOVO\Documents\emp.mdf;Integrated Security=True;Connect Timeout=30";
        private void Form1_Load(object sender, EventArgs e)
        {
            displaydata();
        
        }
        public void displaydata()
        {
            SqlConnection cn = new SqlConnection(con);
            SqlDataAdapter da = new SqlDataAdapter("select * from studinfo",cn);
            DataSet ds = new DataSet();
            da.Fill(ds, "studinfo");
            dataGridView1.DataSource = ds.Tables["studinfo"].DefaultView;



        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtID.Text);
            string name = txtName.Text;
            string city = txtCity.Text;


            SqlConnection cn = new SqlConnection(con);
            cn.Open();
            SqlCommand cmd = new SqlCommand("insert into studinfo values("+id+",'"+name+"','"+city+"')", cn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Inserted Successfully");
            displaydata();
            cn.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtName.Text = "";
            txtCity.Text = "";
        }
    }
}

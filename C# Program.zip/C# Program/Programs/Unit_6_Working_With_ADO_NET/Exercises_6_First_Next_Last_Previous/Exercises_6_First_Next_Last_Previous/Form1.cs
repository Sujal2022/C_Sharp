﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Exercises_6_First_Next_Last_Previous
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\LENOVO\Documents\emp.mdf;Integrated Security=True;Connect Timeout=30");
        DataTable dt = new DataTable();
        int pos = 0;
        int i = 0;
        string gen;
        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from student", con);
            da.Fill(dt);
            showdata(pos);

        }
        public void showdata(int index)
        {
                txtRollno.Text = dt.Rows[i][0].ToString();
                txtName.Text = dt.Rows[i][1].ToString();
                txtStd.Text = dt.Rows[i][3].ToString();
                gen = dt.Rows[i][2].ToString();
                if (gen == "Male")
                {
                    rbtMale.Checked = true;
                }
                else
                {
                    rbtFemale.Checked = true;
                }
           
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {
                i = 0;
                showdata(pos);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (i == dt.Rows.Count-1 || i!=0)
            {
                i--;
                showdata(pos);
            }
            else
            {
                MessageBox.Show("First Record");
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if(i < dt.Rows.Count-1)
            {
                i++;
                showdata(pos);
            }
            else
            {
                MessageBox.Show("Last Record");
                pos = dt.Rows.Count - 1;
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            i = dt.Rows.Count - 1;
            showdata(pos);
        }
    }

}
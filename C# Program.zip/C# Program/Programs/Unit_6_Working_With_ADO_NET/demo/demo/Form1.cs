﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\LENOVO\Documents\emp.mdf;Integrated Security=True;Connect Timeout=30");
        int countryid;
        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from country", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "country");
            con.Close();
            cmbCountry.DisplayMember = "countryname";
            cmbCountry.ValueMember = "countryid";
        }

        private void cmbCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cmbCountry.SelectedValue.ToString()!=null)
            {
                 countryid = Convert.ToInt32(cmbCountry.SelectedValue.ToString());
                 con.Open();
                 SqlDataAdapter da = new SqlDataAdapter("select * from state", con);
                 DataSet ds = new DataSet();
                 da.Fill(ds, "state");
                 con.Close();
                 cmbCountry.DisplayMember = "statename";
                 cmbCountry.ValueMember = "stateid";
                 cmbState.DataSource = ds.Tables["state"].DefaultView;
            }
        }


      

      
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_8_ReadOnly_Fields
{
    class Program
    {
        class demo
        {
            public readonly string str1;
            public readonly string str2;
            public demo(string a,string b)
            {
                str1 = a;
                str2 = b;
                Console.WriteLine("string 1=" +str1);
                Console.WriteLine("string 2=" + str2);
            }
        }
        static void Main(string[] args)
        {
            demo d = new demo("Hello","hi");
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_15_Method_Override
{
    class Program
    {
        public class abc
        {
            public virtual void Display() 
            {
            }
        }

        public class test : abc
        {
            public override void Display()
            {
                Console.WriteLine("Test Method Display!");
            }
        }

        public class test2 : abc
        {
            public override void Display()
            {
                Console.WriteLine("Test2 Display method");
            }
        }
        static void Main(string[] args)
        {
            test2 t = new test2();
            t.Display();
            Console.ReadLine();
        }
    }
}

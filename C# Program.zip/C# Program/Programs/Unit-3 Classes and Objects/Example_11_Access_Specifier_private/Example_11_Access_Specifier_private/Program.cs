﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_11_Access_Specifier_private
{
    class Test
    {
        internal string name = "This is C#";
        internal void Msg(string msg)
        {
            Console.WriteLine("Hi " + msg);
        }
    }  
    class Program
    {
        static void Main(string[] args)
        {
            Test t = new Test();
            Console.WriteLine("Hello " + t.name);
            t.Msg("C Sharp");
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_E_Default_Constructor
{
    class Program
    {
        public class emp
        {
            public emp()//Default Constructor
            {
                Console.WriteLine("Defsult constructor Called");
            }
        }
        static void Main(string[] args)
        {
            emp e = new emp();
            Console.ReadLine();
        }
    }
}

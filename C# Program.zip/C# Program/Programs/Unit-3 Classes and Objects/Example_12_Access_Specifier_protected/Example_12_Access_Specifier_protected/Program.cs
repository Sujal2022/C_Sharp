﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_12_Access_Specifier_protected
{
    class Test
    {
        protected string name = "abc";
        protected void Msg(string m)
        {
            Console.WriteLine("Hi " + m);
        }
    }
    class Program:Test
    {
            static void Main(string[] args)
            {
                Program p = new Program();
                Console.WriteLine("Hello " + p.name);
                p.Msg("C Sharp");
                Console.ReadLine();
            }
        }
    }


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_13_Single_Inheritance
{
    class Program
    {
        class test1
        {
            public void mymethod1()
            {
                Console.WriteLine("Mymethod1 called");
            }
        }
        class test2:test1
        {
            public void mymethod2()
            {
                Console.WriteLine("Mymethod2 called");
            }
        }
        static void Main(string[] args)
        {
            test2 t = new test2();
            t.mymethod1();
            t.mymethod2();
            Console.ReadLine();
        }
    }
}

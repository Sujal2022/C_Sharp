﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_14_Multilevel_Inheritance
{
    class Program
    {
        class test1
        {
            public void method1()
            {
                Console.WriteLine("Method1 called");
            }
        }
        class test2:test1
        {
            public void method2()
            {
                Console.WriteLine("Method2 called");
            }
        }
        class test3 : test2
        {
            public void method3()
            {
                Console.WriteLine("Method3 called");
            }
        }
        static void Main(string[] args)
        {
            test3 t = new test3();
            t.method1();
            t.method2();
            t.method3();
            Console.ReadLine();
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_7_Destructor
{
    class Program
    {
        class emp
        {
            public emp()
            {
                Console.WriteLine("Constructor called");
            }
            ~emp()
            {
                Console.WriteLine("Destructor called");
            }
            static void Main(string[] args)
            {
                emp e = new emp();
                Console.ReadLine();
            }
        }
    }
}

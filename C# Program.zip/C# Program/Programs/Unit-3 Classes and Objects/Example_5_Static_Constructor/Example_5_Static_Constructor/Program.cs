﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_5_Static_Constructor
{
    public class Customer
    {
        static Customer()
        {
            Console.WriteLine("I am static constructor");
        }

        public Customer()
        {
            Console.WriteLine("I am public constructor");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Customer c = new Customer();
            Customer c1 = new Customer();
            Console.ReadLine();
        }
    }
}
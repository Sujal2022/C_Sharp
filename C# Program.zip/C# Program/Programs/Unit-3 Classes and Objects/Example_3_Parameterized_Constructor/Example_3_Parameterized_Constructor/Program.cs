﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_3_Parameterized_Constructor
{
    class Program
    {
        class multiplication
        {            
            public multiplication(int a,int b)
            {
                Console.WriteLine("A=" + a);
                Console.WriteLine("B=" + b);
            }
        }
        static void Main(string[] args)
        {
            multiplication m = new multiplication(10,20);
            Console.ReadLine();
        }
     }
}


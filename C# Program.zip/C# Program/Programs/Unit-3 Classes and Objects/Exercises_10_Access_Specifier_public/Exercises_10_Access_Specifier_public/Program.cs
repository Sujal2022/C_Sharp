﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_10_Access_Specifier_public
{
    class Program
    {
        class Car
        {
            public string type = "BMW";
        }
        static void Main(string[] args)
        {
            Car c = new Car();
            Console.WriteLine(c.type);
            Console.ReadLine();
        }
    }
}

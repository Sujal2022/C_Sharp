﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_16_Method_Overriding
{
    class testing1
    {
        public virtual void test()
        {
            Console.WriteLine("Hi");
        }
    }
    class testing2:testing1
    {
        public override void test()
        {
            Console.WriteLine("Hello");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            testing1 t1 = new testing1();
            testing1 t2 = new testing2();
            t1.test();
            t2.test();
            Console.ReadLine();
        }
    }
}

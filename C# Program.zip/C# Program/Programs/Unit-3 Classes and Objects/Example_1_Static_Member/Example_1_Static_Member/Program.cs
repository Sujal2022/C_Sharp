﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_1_Static_Member
{
    class Program
    {
        class staticvar
        {
            public static int num=0;
            public void count()
            {
                num++;
            }
            public int getnum()
            {
                return num;
            }
        }
     
        static void Main(string[] args)
        {
            staticvar s1 = new staticvar();
            staticvar s2 = new staticvar();
            s1.count();
            s1.count();
            s1.count();

            s2.count();
            s2.count();
            s2.count();

            Console.WriteLine("Variable num for s1: ="+s1.getnum());
            Console.WriteLine("Variable num for s2: ="+s2.getnum());
            Console.ReadLine();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_6_Private_Constructor
{
    public class abc
    {
        // Private constructor
        // without parameter
        private abc()
        {
            Console.WriteLine("private Constructor");
        }
    }
    class Program
    {
        static void Main()
        {
            // This line raise error because
            // the constructor is inaccessible
            abc obj = new abc();
        }
    }
}
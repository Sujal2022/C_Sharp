﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_17_Polymorphism
{
    class testing1
    {
        public void test()
        {
            Console.WriteLine("Hi");
        }
    }
    class testing2 : testing1
    {
        public void test()
        {
            Console.WriteLine("Hello");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            testing1 t1 = new testing1();
            testing1 t2 = new testing2();//here testing1 and testing2 class is different
            t1.test();
            t2.test();
            Console.ReadLine();
        }
    }
}

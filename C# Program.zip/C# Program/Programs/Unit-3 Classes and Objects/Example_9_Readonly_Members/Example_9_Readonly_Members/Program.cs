﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_9_Readonly_Members
{
    class Program
    {
        public readonly struct Author
        {
            public readonly string Name { get; }
            public readonly int Article { get; }
            public readonly string Branch { get; }
            public Author(string name, int article, string branch)
            {

                this.Name = name;
                this.Article = article;
                this.Branch = branch;
            }

            static void Main(string[] args)
            {
                Author a = new Author("Rohit", 67, "CSE");
                Console.WriteLine("Author name: " + a.Name);
                Console.WriteLine("Total articles: " + a.Article);
                Console.WriteLine("Branch name: " + a.Branch);
            }
        }
    }

}

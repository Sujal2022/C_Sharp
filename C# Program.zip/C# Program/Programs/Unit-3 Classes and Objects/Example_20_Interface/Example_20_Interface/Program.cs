﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_20_Interface
{
    interface testing
    {
         void test();
    }
    class testing1 : testing
    {
        public void test()
        {
            Console.WriteLine("Testing method called");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            testing1 t1 = new testing1();
            t1.test();
            Console.ReadLine();
        }
    }
}

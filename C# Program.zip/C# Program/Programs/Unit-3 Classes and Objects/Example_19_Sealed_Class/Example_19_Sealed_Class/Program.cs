﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_19_Sealed_Class
{
    sealed class testing// we can't inherit this class as it is sealed
    {
        public void test()
        {
            Console.WriteLine("Test method called");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            testing t = new testing();
            t.test();
            Console.ReadLine();
       }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_4_Copy_Constructor
{
   
    class Program
    {
        public class Fruit  
        {  
            private double fprice;  //copy constructor
            private String fname;  
            Fruit(double p, String n)  
            {   
                fprice = p;        
                fname = n;          
            }  
            Fruit(Fruit f)  
            {  
                fprice = f.fprice;  
                fname = f.fname;  
            }  
            double showPrice()  
            {  
                return fprice;  
            }  
            String showName()  
            {  
                return fname;  
            }  
            public static void Main(String[] args)  
            {  
                Fruit f1 = new Fruit(399, "Grapes");  
                Console.WriteLine("Name of the first fruit: "+ f1.showName());  
                Console.WriteLine("Price of the first fruit: "+ f1.showPrice());  
                Fruit f2 = new Fruit(f1);  
                Console.WriteLine("Name of the second fruit: "+ f2.showName());  
                Console.WriteLine("Price of the second fruit: "+ f2.showPrice());
                Console.ReadLine();
            }  
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayTest
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] arr = new int[2][];
            arr[0] = new int[] { 1, 2, 3 };
            arr[1] = new int[] { 1, 2, 3, 4, 5 };
            int i, j;
            for(i=0;i<arr.Length;i++)
            {
                for (j = 0; j < arr[i].Length;j++ )
                {
                    Console.WriteLine(arr[i][j]);
                }
            }
            Console.ReadLine();
        }
    }
}

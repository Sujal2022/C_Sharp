﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int A = 10, B = 20, C;
            C = A + B;
            Console.WriteLine("Sum=" + C);
            Console.ReadLine();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_13_Structure
{
    public struct Rectangle
    {
        public int height,width;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle r = new Rectangle();
            r.height = 4;
            r.width = 5;
            int ans = r.height * r.width;
            Console.WriteLine("Area of Rectangle is="+ans);
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array_practice
{
    class Program
    {

        public static void Main()
        {
            int[] arr = new int[5] { 1, 2, 3, 4, 5 };
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("element=[{0}]={1}",i, arr[i]);
            }
            Console.ReadLine();
        }
    }
}


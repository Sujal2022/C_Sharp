﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_11_MultidimentionalArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[2, 3];
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.WriteLine("Enter value=");
                    arr[i,j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.WriteLine(arr[i, j]);
                   
                }
            }
            Console.ReadLine();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_8_Enum
{
    class Program
    {
        enum Level
        {
            Low,
            Medium,
            High
        }
          static void Main(string[] args)
            {
                Level myVar = Level.Medium;
                Console.WriteLine(myVar);
                Console.ReadLine();
            }
        }
    }


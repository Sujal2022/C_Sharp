﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace arrayTesting
{
    class Program
    {
        class calculator
        {
            public delegate void operation(int a, int b);//delegate declaration
            public void sum(int a, int b)
            {
                int c = a + b;
                Console.WriteLine("Sum=" + c);
            }
            public void sub(int a, int b)
            {
                int c = a - b;
                Console.WriteLine("Sub=" + c);
            }
          static void Main(string[] args)
            {
                calculator c = new calculator();
                operation op1 = new operation(c.sum);
                operation op2 = new operation(c.sub);
                op1(10, 20);
                op2(50, 10);
                Console.ReadLine();
            }
        }
    }
}


    

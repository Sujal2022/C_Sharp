﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_1_Array_With_Method
{
    class Program
    {
        static void Main()
        {
            int[] numbers = { 5, 2, 8, 1, 9, 3 };

           /* Console.WriteLine("Original array:");
            DisplayArray(numbers);

            Console.WriteLine("\nSorted array:");
            Array.Sort(numbers);
            DisplayArray(numbers);*/

            Console.WriteLine("\nSum of array elements: " + SumArray(numbers));

            /*Console.WriteLine("\nAverage of array elements: " + AverageArray(numbers));

            Console.Write("\nEnter a number to search: ");
            int searchNumber = int.Parse(Console.ReadLine());
            int index = Array.BinarySearch(numbers, searchNumber);
            if (index >= 0)
            {
                Console.WriteLine("Number found at index " + index);
            }
            else
            {
                Console.WriteLine("Number not found!");
            }
            Console.ReadLine();

            Console.WriteLine("\nReversed array:");
            Array.Reverse(numbers);
            DisplayArray(numbers);

            Console.WriteLine("\nArray with each element squared:");
            SquareArray(numbers);
            DisplayArray(numbers);
        }

        static void DisplayArray(int[] arr)
        {
            foreach (int num in arr)
            {
                Console.Write(num + " ");
            }
        }*/

        static int SumArray(int[] arr)
        {
            int sum = 0;
            foreach (int num in arr)
            {
                sum += num;
            }
            return sum;
        }

        /*static double AverageArray(int[] arr)
        {
            int sum = SumArray(arr);
            return (double)sum / arr.Length;
        }

        static void SquareArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = arr[i] * arr[i];
            }
        }*/
        
    }
}
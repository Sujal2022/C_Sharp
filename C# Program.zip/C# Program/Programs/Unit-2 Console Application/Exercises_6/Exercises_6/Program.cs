﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_6
{
    class Program
    {
        static void Main(string[] args)
        {
            int m1, m2, m3, tot, avg;
            Console.WriteLine("Enter sub1 marks=");
            m1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter sub2 marks=");
            m2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter sub3 marks=");
            m3 = Convert.ToInt32(Console.ReadLine());
            tot = m1 + m2 + m3;
            avg = tot / 3;
            Console.WriteLine("Total=" + tot);
            Console.WriteLine("Average=" + avg);
        }
    }
}

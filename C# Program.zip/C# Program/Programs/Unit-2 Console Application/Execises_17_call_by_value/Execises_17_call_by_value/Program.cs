﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Execises_17_call_by_value
{
    class Program
    {
        public void Display(int a)
        {
            a += a;
            Console.WriteLine("Value inside the function: " + a);
        }
        static void Main(string[] args)
        {
            int a = 100;
            Program p = new Program();
            Console.WriteLine("Value before calling: " + a);
            p.Display(a);
            Console.WriteLine("Value after calling: " + a);
            Console.ReadLine();
        }
    }
}
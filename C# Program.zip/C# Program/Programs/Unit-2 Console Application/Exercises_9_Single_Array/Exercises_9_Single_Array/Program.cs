﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_9_Single_Array
{
    class Program
    {
        static void Main(string[] args)
        {
           int[] a = new int[5];
           //int[] a = new int[5]{10,20,30,40,50};
            a[0] = 10;
            a[1] = 20;
            a[2] = 30;
            a[3] = 40;
            a[4] = 50;
            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine(a[i]);
                //Console.WriteLine("Element[{0}] = {1}", i, a[i]);
            }
            Console.ReadLine();
        }
    }
}

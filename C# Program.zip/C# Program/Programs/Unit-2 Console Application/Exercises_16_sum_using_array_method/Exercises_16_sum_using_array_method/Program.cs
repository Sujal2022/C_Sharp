﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_16_sum_using_array_method
{
    class Program
    {
        static int sum(int[] arr)
        {
            int tot = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                tot = tot + arr[i];
            }
            return tot;
        }
        static int min(int[] arr)
        {
            int min = 0;
            min = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                if (min > arr[i])
                {
                    min = arr[i];
                }
                
            }
            return min;
        }
        static int max(int[] arr)
        {
            int max = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (max < arr[i])
                {
                    max = arr[i];
                }
            }
            return max;
        }
        static int even(int[] arr)
        {
            int e=0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 2 == 0)
                {
                    e = arr[i];
                    Console.WriteLine("even=" + e);
                }
            }
            return e;

        }
        static int odd(int[] arr)
        {
            int o = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 2 != 0)
                {
                    o = arr[i];
                    Console.WriteLine("even=" + o);
                }
            }
            return o;

        }

        public static void Main()
        {
            int[] arr = new int[5];
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write("Enter element-[{0}]", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("Sum=" + sum(arr));
            Console.WriteLine("min=" + min(arr));
            Console.WriteLine("max=" + max(arr));
            Console.WriteLine("even=" + even(arr));
            Console.WriteLine("odd=" + odd(arr));
            Console.ReadLine();
        }
    }
    
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_18_out_parameters
{
    class Program
    {
        
        static void Main(string[] args)
        {
           // char ch = 'A';
            for (char c = 'A'; c < 'Z'; c++)
            {
                Console.Write(c + "\t");
            }
           
            Console.ReadLine();

        }
    }
}
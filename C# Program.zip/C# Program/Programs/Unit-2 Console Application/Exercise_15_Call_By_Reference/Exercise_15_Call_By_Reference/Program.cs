﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_15_Call_By_Reference
{
     class Program      
     { 
         // User defined function
         public void Show(ref int val) 
         {
             val += val; // Manipulating value
             Console.WriteLine("Value inside the show function "+val);// No return statement          
         }          
         // Main function, execution entry point of the program  
         static void Main(string[] args)      
         { 
             int val = 10;              
             Program program = new Program(); // Creating Object  
             Console.WriteLine("Value before calling the function "+val);    
             program.Show(ref val); // Calling Function by passing reference                      
             Console.WriteLine("Value after calling the function " + val);
             Console.ReadLine();
         }  
     } 
} 


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_7
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            Console.WriteLine("Enter any number=");
            i = Convert.ToInt32(Console.ReadLine());
            if (i > 0)
            {
                Console.WriteLine("Positive");
            }
            else if (i < 0)
            {
                Console.WriteLine("Negative");
            }
            else
            {
                Console.WriteLine("Zero");
            }
            Console.ReadLine(); 
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_22_Jagged_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            //jagged array is array of array and here in first bracket we mention 2 that means in that 2 there is another 2 array
            int[][] arr= new int[2][];
            arr[0] = new int[] { 1, 2 };
            arr[1] = new int[] { 1, 2,3,4,5 };
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    Console.Write(arr[i][j]+"\t");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
             
        }
    }
}

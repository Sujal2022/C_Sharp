﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_14_Methods
{
    class Program
    {
        static void MyMethod()
        {
            Console.WriteLine("Method is exucuted");
        }
        static void Main(string[] args)
        {
            MyMethod();
            Console.ReadLine();
        }
    }
}

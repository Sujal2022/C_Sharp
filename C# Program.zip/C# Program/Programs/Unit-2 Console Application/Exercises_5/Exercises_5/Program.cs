﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_5
{
    class Program
    {
        static void Main(string[] args)
        {
            String s;
            Console.WriteLine("Enter your name=");
            s = Console.ReadLine();
            Console.WriteLine("Your name is="+s);
            Console.Read();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_10_Array_sum
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("Enter value=");
                arr[i] = Convert.ToInt32(Console.ReadLine());
                sum = sum + arr[i];
            }
            Console.WriteLine("Sum=" + sum);
            Console.ReadLine();
        }
    }
}

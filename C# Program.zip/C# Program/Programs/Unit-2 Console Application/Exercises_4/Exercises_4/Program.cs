﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("Enter a=");
            a=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter b=");
            b = Convert.ToInt32(Console.ReadLine());
            c = a + b;
            Console.WriteLine("Sum="+c);
            Console.ReadLine();

        }
    }
}

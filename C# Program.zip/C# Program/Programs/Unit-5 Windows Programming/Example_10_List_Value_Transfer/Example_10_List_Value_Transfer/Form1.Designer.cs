﻿namespace Example_10_List_Value_Transfer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListBox1 = new System.Windows.Forms.ListBox();
            this.ListBox2 = new System.Windows.Forms.ListBox();
            this.ShiftRight = new System.Windows.Forms.Button();
            this.ShiftLeft = new System.Windows.Forms.Button();
            this.ShiftAllRight = new System.Windows.Forms.Button();
            this.ShiftAllLeft = new System.Windows.Forms.Button();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.Add = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ListBox1
            // 
            this.ListBox1.FormattingEnabled = true;
            this.ListBox1.Items.AddRange(new object[] {
            "Rajkot",
            "Pune",
            "Surat",
            "Ahmedabad",
            "Jamnagar",
            "Morbi"});
            this.ListBox1.Location = new System.Drawing.Point(23, 132);
            this.ListBox1.Name = "ListBox1";
            this.ListBox1.Size = new System.Drawing.Size(120, 134);
            this.ListBox1.TabIndex = 0;
            // 
            // ListBox2
            // 
            this.ListBox2.FormattingEnabled = true;
            this.ListBox2.Location = new System.Drawing.Point(279, 132);
            this.ListBox2.Name = "ListBox2";
            this.ListBox2.Size = new System.Drawing.Size(120, 134);
            this.ListBox2.TabIndex = 1;
            // 
            // ShiftRight
            // 
            this.ShiftRight.Location = new System.Drawing.Point(174, 132);
            this.ShiftRight.Name = "ShiftRight";
            this.ShiftRight.Size = new System.Drawing.Size(75, 23);
            this.ShiftRight.TabIndex = 2;
            this.ShiftRight.Text = ">";
            this.ShiftRight.UseVisualStyleBackColor = true;
            this.ShiftRight.Click += new System.EventHandler(this.ShiftRight_Click);
            // 
            // ShiftLeft
            // 
            this.ShiftLeft.Location = new System.Drawing.Point(174, 163);
            this.ShiftLeft.Name = "ShiftLeft";
            this.ShiftLeft.Size = new System.Drawing.Size(75, 23);
            this.ShiftLeft.TabIndex = 3;
            this.ShiftLeft.Text = "<";
            this.ShiftLeft.UseVisualStyleBackColor = true;
            this.ShiftLeft.Click += new System.EventHandler(this.ShiftLeft_Click);
            // 
            // ShiftAllRight
            // 
            this.ShiftAllRight.Location = new System.Drawing.Point(174, 196);
            this.ShiftAllRight.Name = "ShiftAllRight";
            this.ShiftAllRight.Size = new System.Drawing.Size(75, 23);
            this.ShiftAllRight.TabIndex = 4;
            this.ShiftAllRight.Text = ">>";
            this.ShiftAllRight.UseVisualStyleBackColor = true;
            this.ShiftAllRight.Click += new System.EventHandler(this.ShiftAllRight_Click);
            // 
            // ShiftAllLeft
            // 
            this.ShiftAllLeft.Location = new System.Drawing.Point(174, 232);
            this.ShiftAllLeft.Name = "ShiftAllLeft";
            this.ShiftAllLeft.Size = new System.Drawing.Size(75, 23);
            this.ShiftAllLeft.TabIndex = 5;
            this.ShiftAllLeft.Text = "<<";
            this.ShiftAllLeft.UseVisualStyleBackColor = true;
            this.ShiftAllLeft.Click += new System.EventHandler(this.ShiftAllLeft_Click);
            // 
            // TextBox1
            // 
            this.TextBox1.Location = new System.Drawing.Point(43, 76);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(100, 20);
            this.TextBox1.TabIndex = 6;
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(174, 73);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(75, 23);
            this.Add.TabIndex = 7;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(258, 73);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 8;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 412);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.TextBox1);
            this.Controls.Add(this.ShiftAllLeft);
            this.Controls.Add(this.ShiftAllRight);
            this.Controls.Add(this.ShiftLeft);
            this.Controls.Add(this.ShiftRight);
            this.Controls.Add(this.ListBox2);
            this.Controls.Add(this.ListBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox ListBox1;
        private System.Windows.Forms.ListBox ListBox2;
        private System.Windows.Forms.Button ShiftRight;
        private System.Windows.Forms.Button ShiftLeft;
        private System.Windows.Forms.Button ShiftAllRight;
        private System.Windows.Forms.Button ShiftAllLeft;
        private System.Windows.Forms.TextBox TextBox1;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button btnRemove;
    }
}


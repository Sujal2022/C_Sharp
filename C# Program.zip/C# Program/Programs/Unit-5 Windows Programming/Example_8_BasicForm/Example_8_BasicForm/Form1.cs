﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_8_BasicForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string gen, name,info, other;
            other = txtOther.Text.ToString();
            name = txtName.Text.ToString();
            if (rbtMale.Checked == true)
            {
                gen = "Male";
            }
            else
            {
                gen = "Female";
            }
            if (chkWebsite.Checked == true)
            {
                info = "website";
            }
            else if (chkFriends.Checked == true)
            {
                info = "Friends";
            }
            else if (chkNewsPaper.Checked == true)
            {
                info = "News Paper";
            }
            else
            {
                info = "others";
            }
            MessageBox.Show("Hello " + name + "you know about us from " + info + other);
           
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_5_BasicInfo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string name, add, gen, lang, city;
            name = txtName.Text;
            add = txtAdd.Text;
            city = lstCity.SelectedItem.ToString();
            if (chkEnglish.Checked == true)
            {
                lang = "English";
            }
            else
            {
                lang = "Gujarati";
            }
            if (rbtMale.Checked == true)
            {
                gen = "Male";
            }
            else
            {
                gen = "Female";
            }
        }
    }
}

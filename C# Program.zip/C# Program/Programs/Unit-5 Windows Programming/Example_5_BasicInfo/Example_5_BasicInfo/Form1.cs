﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_5_BasicInfo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string city = lstCity.SelectedItem.ToString();
            string name, add;
            name = txtName.Text;
            add = txtAdd.Text;
            string gender;
            if (rbtFemale.Checked == true)
            {
                gender = "Female";
            }
            else
            {
                gender = "Male";
            }
            string language;
            if (chkCSharp.Checked == true)
            {
                language = "C Sharp";
            }
            else
            {
                language = "J2EE";
            }
            MessageBox.Show("Your name=" + name + 
                "\n" + "Adress=" + add + "\n" + "Gender=" + gender  +
                "\n" + "Language=" + language +"\n" + "City=" + city);

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            //MessageBox.Show(city);
        }
    }
}

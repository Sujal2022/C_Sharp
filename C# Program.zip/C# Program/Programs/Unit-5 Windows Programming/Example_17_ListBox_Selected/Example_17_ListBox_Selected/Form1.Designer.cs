﻿namespace Example_17_ListBox_Selected
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetSelected = new System.Windows.Forms.Button();
            this.btnClearSelected = new System.Windows.Forms.Button();
            this.btnSelSelected = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnGetSelected
            // 
            this.btnGetSelected.Location = new System.Drawing.Point(70, 264);
            this.btnGetSelected.Name = "btnGetSelected";
            this.btnGetSelected.Size = new System.Drawing.Size(97, 23);
            this.btnGetSelected.TabIndex = 0;
            this.btnGetSelected.Text = "Get Selected";
            this.btnGetSelected.UseVisualStyleBackColor = true;
            this.btnGetSelected.Click += new System.EventHandler(this.btnGetSelected_Click);
            // 
            // btnClearSelected
            // 
            this.btnClearSelected.Location = new System.Drawing.Point(184, 264);
            this.btnClearSelected.Name = "btnClearSelected";
            this.btnClearSelected.Size = new System.Drawing.Size(114, 23);
            this.btnClearSelected.TabIndex = 1;
            this.btnClearSelected.Text = "Clear Selected";
            this.btnClearSelected.UseVisualStyleBackColor = true;
            this.btnClearSelected.Click += new System.EventHandler(this.btnClearSelected_Click);
            // 
            // btnSelSelected
            // 
            this.btnSelSelected.Location = new System.Drawing.Point(304, 264);
            this.btnSelSelected.Name = "btnSelSelected";
            this.btnSelSelected.Size = new System.Drawing.Size(113, 23);
            this.btnSelSelected.TabIndex = 2;
            this.btnSelSelected.Text = "Set Selected";
            this.btnSelSelected.UseVisualStyleBackColor = true;
            this.btnSelSelected.Click += new System.EventHandler(this.btnSelSelected_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "Rajkot",
            "Pune",
            "Surat",
            "Baroda",
            "Ahmedabad",
            "Mehsana"});
            this.listBox1.Location = new System.Drawing.Point(70, 63);
            this.listBox1.Name = "listBox1";
            this.listBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBox1.Size = new System.Drawing.Size(127, 173);
            this.listBox1.TabIndex = 3;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(277, 63);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 173);
            this.listBox2.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 453);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btnSelSelected);
            this.Controls.Add(this.btnClearSelected);
            this.Controls.Add(this.btnGetSelected);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGetSelected;
        private System.Windows.Forms.Button btnClearSelected;
        private System.Windows.Forms.Button btnSelSelected;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
    }
}


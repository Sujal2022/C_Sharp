﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_17_ListBox_Selected
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGetSelected_Click(object sender, EventArgs e)
        {
            //set multiselect property=MultiSimple of ListBox1
            for (int i = 0; i<listBox1.Items.Count; i++)
            {
                if (listBox1.GetSelected(i) == true)
                {
                    listBox2.Items.Add(listBox1.Items[i]);
                }
            }
        }

        private void btnClearSelected_Click(object sender, EventArgs e)
        {
            listBox1.ClearSelected();
        }

        private void btnSelSelected_Click(object sender, EventArgs e)
        {
            for (int i = 0; i<listBox1.Items.Count; i = i + 2)
            {
                if (listBox1.GetSelected(i) == true)
                {
                    listBox1.SetSelected(i, true);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_16_ListBox_Properties
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnContains_Click(object sender, EventArgs e)
        {
            string str = txtContains.Text;
            if (listBox1.Items.Contains(str))
            {
                MessageBox.Show("Yes in the list");
            }
            else
            {
                MessageBox.Show("Not the list");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("Rajkot");
            listBox1.Items.Add("Pune");
            listBox1.Items.Add("Surat");
            listBox1.Items.Add("Ahmedabad");
            listBox1.Items.Add("Baroda");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void btnIndex_Click(object sender, EventArgs e)
        {
            string str = txtIndex.Text;
            int pos= listBox1.Items.IndexOf(str);
            if(pos>-1)
            {
                MessageBox.Show("position="+pos);
            }
            else
            {
                MessageBox.Show("Not fount position"+pos);
            }
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove(txtRemove.Text);
        }

        private void btnRemoveAt_Click(object sender, EventArgs e)
        {
            int pos = Convert.ToInt32(txtRemoveAt.Text);
            listBox1.Items.RemoveAt(pos);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_14_OnlyNumber_or_OnlyText
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            int no;
            no = Convert.ToInt32(e.KeyChar);
            if ((no >= 48 && no <= 57) || no == 46 || no == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtUpper_KeyPress(object sender, KeyPressEventArgs e)
        {
            int no;
            no = Convert.ToInt32(e.KeyChar);
            if((no>=65 && no<=90)|| no==8)
            {
                e.Handled=false;
            }
            else
            {
                e.Handled=true;
            }

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            int no;
            no = Convert.ToInt16(e.KeyChar);
            if((no>=97 && no<=122)|| no==8)
            {
                e.Handled=false;
            }
            else
            {
                e.Handled=true;
            }

        }
    }
}

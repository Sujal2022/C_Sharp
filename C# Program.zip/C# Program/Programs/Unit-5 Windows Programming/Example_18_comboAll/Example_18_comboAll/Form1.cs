﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_18_comboAll
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string str = null;
            str = txtData.Text;
            if (cmbCity.FindString(str) > -1)
            {
                MessageBox.Show("Already in the list", "Error");
            }
            else
            {
                cmbCity.Items.Add(str);
                txtData.Clear();
            }
        }

        private void btnRemoveSelected_Click(object sender, EventArgs e)
        {
            cmbCity.Items.Remove(cmbCity.SelectedItem);
        }

        private void btnRemoveAt_Click(object sender, EventArgs e)
        {
            cmbCity.Items.RemoveAt(cmbCity.SelectedIndex);
        }

        private void btnInsertItem_Click(object sender, EventArgs e)
        {
            string pos = null;
            string str = null;
            pos = txtPosition.Text;
            str = txtData.Text;
            if (cmbCity.FindString(str) > -1)
            {
                MessageBox.Show("Already in the list", "Error");
            }
            else
            {
                cmbCity.Items.Insert(Convert.ToInt16(pos), Convert.ToString(str));
                txtData.Clear();
                txtPosition.Clear();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cmbCity.Items.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Convert.ToString(cmbCity.SelectedItem));
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Convert.ToString(cmbCity.Items.Count));
        }
    }
}

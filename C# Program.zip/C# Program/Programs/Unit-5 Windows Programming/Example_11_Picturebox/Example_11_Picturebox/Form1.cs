﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_11_Picturebox
{
    public partial class Form1 : Form
    {
        Image file;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog of = new OpenFileDialog();
            of.Filter = "JPG(*.jpg)|*.jpg";
            if (of.ShowDialog() == DialogResult.OK)
            {
                file = Image.FromFile(of.FileName);
                pictureBox1.Image = file;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "JPG (*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file.Save(f.FileName);

            }  
        }
    }
}

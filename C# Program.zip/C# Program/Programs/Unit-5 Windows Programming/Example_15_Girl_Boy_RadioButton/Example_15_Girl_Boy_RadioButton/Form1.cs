﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_15_Girl_Boy_RadioButton
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rbtBoy_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("E:\\RKU\\SEM5\\C#\\Programs\\Unit-5 Windows Programming\\Example_15_Girl_Boy_RadioButton\\boy.jpg");
        }

        private void rbtGirl_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("E:\\RKU\\SEM5\\C#\\Programs\\Unit-5 Windows Programming\\Example_15_Girl_Boy_RadioButton\\girl.jpg");
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            string name, gen;
            name = txtName.Text;
            if (rbtBoy.Checked == true)
            {
                gen = "Boy";
            }
            else
            {
                gen = "Girl";
            }
            MessageBox.Show("Name=" + name + "Gender = " + gen);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

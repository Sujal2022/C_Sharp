﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_18_ListBox_with_Checkbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LstMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            LstPrice.ClearSelected();
            for (int i = 0; i < LstMenu.Items.Count; i++)
            {
                if (LstMenu.GetItemChecked(i) == true)
                {
                    LstPrice.SetItemChecked(i, true);
                }
            }
        }

        private void btnTotalBill_Click(object sender, EventArgs e)
        {
            int total = 0;
            for (int i = 0; i < LstPrice.Items.Count; i++)
            {
                if (LstPrice.GetItemChecked(i) == true)
                {
                    total = total + Convert.ToInt32(LstPrice.Items[i]);
                }
                lblBill.Text = "Total Bill="+total.ToString();
            }
        }
    }
}

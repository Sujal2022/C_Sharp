﻿namespace Example_18_ListBox_with_Checkbox
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LstMenu = new System.Windows.Forms.CheckedListBox();
            this.btnTotalBill = new System.Windows.Forms.Button();
            this.LstPrice = new System.Windows.Forms.CheckedListBox();
            this.lblBill = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LstMenu
            // 
            this.LstMenu.FormattingEnabled = true;
            this.LstMenu.Items.AddRange(new object[] {
            "Maggie",
            "Pav Bhajji",
            "Pizza",
            "Burger",
            "HotDog"});
            this.LstMenu.Location = new System.Drawing.Point(97, 82);
            this.LstMenu.Name = "LstMenu";
            this.LstMenu.Size = new System.Drawing.Size(135, 154);
            this.LstMenu.TabIndex = 0;
            this.LstMenu.SelectedIndexChanged += new System.EventHandler(this.LstMenu_SelectedIndexChanged);
            // 
            // btnTotalBill
            // 
            this.btnTotalBill.Location = new System.Drawing.Point(214, 324);
            this.btnTotalBill.Name = "btnTotalBill";
            this.btnTotalBill.Size = new System.Drawing.Size(75, 23);
            this.btnTotalBill.TabIndex = 1;
            this.btnTotalBill.Text = "Total Bill";
            this.btnTotalBill.UseVisualStyleBackColor = true;
            this.btnTotalBill.Click += new System.EventHandler(this.btnTotalBill_Click);
            // 
            // LstPrice
            // 
            this.LstPrice.FormattingEnabled = true;
            this.LstPrice.Items.AddRange(new object[] {
            "50",
            "70",
            "350",
            "125",
            "80"});
            this.LstPrice.Location = new System.Drawing.Point(255, 82);
            this.LstPrice.Name = "LstPrice";
            this.LstPrice.Size = new System.Drawing.Size(109, 154);
            this.LstPrice.TabIndex = 2;
            // 
            // lblBill
            // 
            this.lblBill.AutoSize = true;
            this.lblBill.Location = new System.Drawing.Point(252, 269);
            this.lblBill.Name = "lblBill";
            this.lblBill.Size = new System.Drawing.Size(0, 13);
            this.lblBill.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 412);
            this.Controls.Add(this.lblBill);
            this.Controls.Add(this.LstPrice);
            this.Controls.Add(this.btnTotalBill);
            this.Controls.Add(this.LstMenu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox LstMenu;
        private System.Windows.Forms.Button btnTotalBill;
        private System.Windows.Forms.CheckedListBox LstPrice;
        private System.Windows.Forms.Label lblBill;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_19_ArithmaticOperation_UsingCombo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cmbOperation_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a, b, c;
            a = Convert.ToInt32(txtNo1.Text);
            b = Convert.ToInt32(txtNo2.Text);
            if (cmbOperation.Text == "+")
            {
                c = a + b;
                txtAnswer.Text = c.ToString();
            }
            else if (cmbOperation.Text == "-")
            {
                c = a - b;
                txtAnswer.Text = c.ToString();

            }
            else if (cmbOperation.Text == "*")
            {
                c = a * b;
                txtAnswer.Text = c.ToString();
            }
            else if (cmbOperation.Text == "/")
            {
                c = a / b;
                txtAnswer.Text = c.ToString();
            }


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_13_Cut_Copy_Paste
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCut_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void btnPaste_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void btnRedo_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void btnUpper_Click(object sender, EventArgs e)
        {
           richTextBox1.Text = richTextBox1.Text.ToUpper();
        }

        private void btnLower_Click(object sender, EventArgs e)
        {
           richTextBox1.Text =  richTextBox1.Text.ToLower();
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }
    }
}

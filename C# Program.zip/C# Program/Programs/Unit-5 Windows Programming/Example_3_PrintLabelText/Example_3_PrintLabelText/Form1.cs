﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example_3_PrintLabelText
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtText_Click(object sender, EventArgs e)
        {
            //print textbox value in to lable
            lblTxt.Text = textBox1.Text.ToString();
        }
    }
}
